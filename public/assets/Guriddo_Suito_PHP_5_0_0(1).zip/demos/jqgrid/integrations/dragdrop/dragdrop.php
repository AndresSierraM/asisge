<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 * 
 */
$rowid = $_GET['OrderID'];
echo "Row: ".$rowid." succefull droped from orders and added in table2";
// we can get all the data from the grid delete it from orders and insert it into the new table

